package lpgDTO;

public class UserChampionPreferenceDTO {
	private int prechampNO;
	private int lolId;
	private String lolPrech1;
	private String lolPrech2;
	private String lolPrech3;
	private char prefer;
	
	public UserChampionPreferenceDTO() {
		
	}
}
