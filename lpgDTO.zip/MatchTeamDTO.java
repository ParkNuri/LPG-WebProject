package lpgDTO;

public class MatchTeamDTO {
	private int mchTeamNo;
	private int mchNo;
	private int teamNo;
	private int backupNum;
	
	public MatchTeamDTO() {
		
	}

}
