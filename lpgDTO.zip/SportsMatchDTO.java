package lpgDTO;

import java.sql.Date;

public class SportsMatchDTO {
	private int mchNo;
	private String mchName;
	private Date mchDate;
	private String mchPlay;
	private String mchGrd;
	private int mchPrice;
	private String mchUrgent;
	private String mchContent;
	private String mchGender;
	private String mchShoes;
	private String mchAbil;
	private String mchType;
	
	public SportsMatchDTO() {
		
	}
	

}
