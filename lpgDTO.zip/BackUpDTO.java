package lpgDTO;

public class BackUpDTO {
	private int backupNo;
	private int mchTeamNo;
	private String userId;
	private String comment;
	private char backupApply;
}
