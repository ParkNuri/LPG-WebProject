package lpgDTO;

import java.sql.Date;

public class ContestDTO {
	private int contestNo;
	private String contestName;
	private String contestAgency;
	private String contestField;
	private String contestTarget;
	private Date contestApplyStartDate;
	private Date contestApplyEndDate;
	private Date contestStartDate;
	private Date contestEndDate;
	private String contestLocation;
	private String agencyHome;
	private String agencyPhone;
	private String contestImg;
	
	public ContestDTO() {
		
	}
	
	
	
}
