package lpgDTO;

public class MatchResultDTO {
	private int matchResult;
	private int matchNo;
	private int matchTeamNo;
	private char matchGA;
	private String matchGainer;
	
	public MatchResultDTO() {
		
	}
	

}
