package lpgDTO;

public class TierDTO {
	private int tierNo;
	private String lolId;
	private String gameType;
	private String tier;
	
	public TierDTO() {
		
	}
}
