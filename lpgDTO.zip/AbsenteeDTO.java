package lpgDTO;

public class AbsenteeDTO {
	private int absentNo;
	private int usNo;
	private int matchNo;
	
	public AbsenteeDTO() {
		
	}
	
}
