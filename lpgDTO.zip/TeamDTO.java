package lpgDTO;

import java.sql.Date;

public class TeamDTO {
	private int teamNo;
	private String teamName;
	private String teamIntroduce;
	private String teamLocation;
	private String teamGround;
	private String teamAbility;
	private String teamUniform;
	private String teamManner;
	private String teamStrategy;
	private String teamSoccerPre;
	private String teamFutPre;
	private Date teamCreateDate;
	private int teamAge;
	private String teamEmblem;
	private char memverPrivate;
	
	public TeamDTO() {
		
	}

}
