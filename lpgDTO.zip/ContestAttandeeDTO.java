package lpgDTO;

public class ContestAttandeeDTO {

	private int caNo;
	private int teamNo;
	private int contestNO;
	private String userId;
	
	public ContestAttandeeDTO() {
		
	}
}
