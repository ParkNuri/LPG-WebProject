package lpgDTO;

public class UserSportsDTO {
	private int ueNo;
	private String userId;
	private String userPosition;
	private String userTend;
	private String userFoot;
	
	public UserSportsDTO() {
		
	}
	
	
}
