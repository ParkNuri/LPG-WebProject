package lpgDTO;

public class EsprotsGroupDTO {
	private int lolGroupid;
	private String lolFgroup;
	
	public EsprotsGroupDTO() {
		
	}
}
