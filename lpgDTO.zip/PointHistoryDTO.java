package lpgDTO;

import java.sql.Date;

public class PointHistoryDTO {
	private int pointNO;
	private String userId; 
	private int pointPrice;
	private char pointUSer ;
	private Date pointUseDate;
	private String pointHistory;
	
	public  PointHistoryDTO() {
		
	}
}
	