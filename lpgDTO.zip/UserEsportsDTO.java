package lpgDTO;

public class UserEsportsDTO {
	private String lolId;
	private String userId;
	private String lolTier;
	private String lolTrend;
	private String lolWinRate;
	private String lolRank;
	private String lolPoint;

	public UserEsportsDTO() {
		
	}
}
