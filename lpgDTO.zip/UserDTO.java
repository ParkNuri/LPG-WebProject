package lpgDTO;

import java.sql.Date;

public class UserDTO {
	private String userId;
	private String userPwd;
	private String userName;
	private String userNick;
	private int userPhone;
	private Date userBirth;
	private String userAddr;
	private Date userSignDate;
	private char userGender;
	private String userEmail;
	private char userEmailAgree;
	private int userPoint;

	public UserDTO() {
		
	}
}