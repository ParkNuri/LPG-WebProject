package lpgDTO;

import java.sql.Date;

public class GroundReserveDTO {

	private int grdrsvNo;
	private int grdNo;
	private Date grdrsvUseDate;
	private String grdrsvStartTime;
	private String grdrsvEndTime;
	private Date grdrsvDate;
	private Date grdrsvCancStartDate;
	private Date grdrsvCancEndDate;
	private String userId;
	
	public GroundReserveDTO() {
		
	}
	
}
