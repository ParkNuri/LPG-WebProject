package lpgDTO;

public class ChampionInfoDTO {
	private int chNo;
	private String chName;
	private int winRate;
	private String chImg;
	private int pickRate;
	private String chTier;
	private int banRate;
	
	public ChampionInfoDTO() {
		
	}

}
