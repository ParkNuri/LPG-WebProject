package lpgDTO;

public class QImgDTO {
	private int qImgNo;
	private int qNo;
	private String qImgName;
	
	public QImgDTO() {
		
	}

}
