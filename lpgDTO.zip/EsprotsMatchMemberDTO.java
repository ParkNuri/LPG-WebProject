package lpgDTO;

public class EsprotsMatchMemberDTO {
	private int mmNo;
	private String ueNo;
	private String mmPos;
	
	public EsprotsMatchMemberDTO() {
		
	}

}
