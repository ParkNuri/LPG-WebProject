package lpgDTO;

public class SpotsMatchIndividualDTO {
	private int mchinNo;
	private int userId;
	private int mchNo;
	
	public SpotsMatchIndividualDTO() {
		
	}
	
}
