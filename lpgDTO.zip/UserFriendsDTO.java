package lpgDTO;

public class UserFriendsDTO {
	private int fNo;
	private int ueNo;
	private int lolGroupId;
	private String lolMemo;
	private char lolBan;
	
	public UserFriendsDTO() {
		
	}
	

}
