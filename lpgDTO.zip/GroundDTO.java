package lpgDTO;

public class GroundDTO {
	private int grdNo;
	private String grdName;
	private String grdAddr;
	private String grdPhone;
	private String grdArea;
	private String grdDetail;
	private int grdCost;
	
	public GroundDTO() {
		
	}
}
