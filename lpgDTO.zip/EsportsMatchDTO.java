package lpgDTO;

import java.sql.Date;

public class EsportsMatchDTO {
	private int mrNo;
	private String roomName;
	private String roomPass;
	private int memCount;
	private String posStat;
	private String gameSort;
	private Date matcreDate;
	
	public EsportsMatchDTO() {
		
	}

}
