package lpgDTO;

import java.sql.Date;

public class QnADTO {
	private int bNo;
	private String userId;
	private int questionNo;
	private String qTitle;
	private String qContents;
	private Date qDate;
	private String qHit;
	private String qPrivate;
	private String qPass;
	
	public QnADTO() {
		
	}
}
