package lpgDTO;

import java.sql.Date;

public class TeamMemberDTO {
	private int tmNo;
	private Date tmJoinDate;
	private String tmGrade;
	private int teamNo;
	private int usNo;
	private String tmTend;
	private String tmAbility;
	private int backNum;
	
	public TeamMemberDTO() {
		
	}
}
