package lpgDTO;

public class UserMannerDTO {
	private int umNo;
	private int lolId;
	private int manner;
	private int power;
	private int friendly;
	private int bad;
	
	public UserMannerDTO() {
		
	}
}
