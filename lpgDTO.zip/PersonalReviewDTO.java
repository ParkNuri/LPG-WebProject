package lpgDTO;

import java.sql.Date;

public class PersonalReviewDTO {
	private int prNo;
	private int matchNo;
	private int reviewerld;
	private int getterId;
	private Date reviewDate;
	private int mannerScore;
	private int contributeScore;
	
	public PersonalReviewDTO() {
		
	}
	
}
