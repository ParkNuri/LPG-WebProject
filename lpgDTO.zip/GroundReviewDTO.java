package lpgDTO;

public class GroundReviewDTO {
	private int grdrevNo;
	private int grdNo;
	private String grdrevContext;
	private int grdrevStar;
	private int grdrevQ1;
	private int grdrevQ2;
	private int grdrevQ3;
	private int usNo;
	
	public GroundReviewDTO() {
		
	}
	

}
