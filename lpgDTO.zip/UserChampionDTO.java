package lpgDTO;

public class UserChampionDTO {
	private int myChampNo;
	private int lolId;
	private int lolCh;
}
